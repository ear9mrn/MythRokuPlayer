<?php

// Redirect people who try to view this folder to the main index.php page
header("Location:../../");

?>

